package appointment;
import java.util.Scanner;
import doctor.Doctor_info;
import doctor.Doctor_management;
import patient.Patient_info;
import java.util.ArrayList;

public class AppointmentScheduler {
    private static Scanner scanner = new Scanner(System.in);

    public static void scheduleAppointment(ArrayList<Patient_info> patients) {
        System.out.print("Enter Patient ID: ");
        int pid = scanner.nextInt();
        scanner.nextLine();

        Patient_info patient = null;
        for (Patient_info p : patients) {
            if (p.getid() == pid) {
                patient = p;
                break;
            }
        }

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        System.out.print("Enter Doctor ID: ");
        int did = scanner.nextInt();
        scanner.nextLine();

        Doctor_info doctor = null;
        for (Doctor_info d : Doctor_management.doctors) {
            if (d.getDoctorId() == did) {
                doctor = d;
                break;
            }
        }

        if (doctor == null) {
            System.out.println("Doctor not found.");
            return;
        }

        System.out.println("\n--- Appointment Scheduled ---");
        System.out.println("Patient Name : " + patient.getname());
        System.out.println("Doctor Name  : " + doctor.getName());
    }
}