package billing;

import java.util.Scanner;
import patient.Patient_info;
public class Billing {
	private static Scanner scanner = new Scanner(System.in);

    public static void generateBill(Patient_info patient) {
        System.out.print("Enter Treatment Charges: ");
        double treatment = scanner.nextDouble();
        System.out.print("Enter Medicine Charges: ");
        double medicine = scanner.nextDouble();
        System.out.print("Enter Room Charges: ");
        double room = scanner.nextDouble();

        double total = treatment + medicine + room;
        System.out.println("\n--- Bill Receipt ---");
        System.out.println("Patient: " + patient.getname());
        System.out.println("Total Bill: ₹" + total);
    }

}