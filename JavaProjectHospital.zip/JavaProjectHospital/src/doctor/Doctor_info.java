package doctor;

public class Doctor_info {
    private int doctor_id;
    private String name;
    private String specialization;
    private String contact;
	public String doctor_name;

    public Doctor_info(int doctor_id, String name, String specialization, String contact) {
        this.doctor_id = doctor_id;
        this.name = name;
        this.specialization = specialization;
        this.contact = contact;
    }

    public int getDoctorId() {
        return doctor_id;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public String getContact() {
        return contact;
    }

    public void displayDoctorInfo() {
        System.out.println("\n--- Doctor Details ---");
        System.out.println("ID             : " + doctor_id);
        System.out.println("Name           : " + name);
        System.out.println("Specialization : " + specialization);
        System.out.println("Contact        : " + contact);
        System.out.println("--------------------------");
    }
}