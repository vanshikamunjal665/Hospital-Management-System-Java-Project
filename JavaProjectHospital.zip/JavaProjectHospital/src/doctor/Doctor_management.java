package doctor;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Doctor_management {
    public static ArrayList<Doctor_info> doctors = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static final String FILE_NAME = "doctors.txt";

    public static void loadDoctorsFromFile() {
        doctors.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String name = reader.readLine();
                String specialization = reader.readLine();
                String contact = reader.readLine();
                int doctor_id = Integer.parseInt(line);
                doctors.add(new Doctor_info(doctor_id, name, specialization, contact));
            }
        } catch (FileNotFoundException e) {
            // File doesn't exist on first run
        } catch (IOException e) {
            System.out.println("Error reading doctors file: " + e.getMessage());
        }
    }

    public static void saveDoctorsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Doctor_info d : doctors) {
                writer.write(String.valueOf(d.getDoctorId()));
                writer.newLine();
                writer.write(d.getName());
                writer.newLine();
                writer.write(d.getSpecialization());
                writer.newLine();
                writer.write(d.getContact());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing doctors file: " + e.getMessage());
        }
    }

    public static void addDoctor() {
        System.out.print("Enter Doctor ID: ");
        int doctor_id = scanner.nextInt();
        scanner.nextLine();

        for (Doctor_info d : doctors) {
            if (d.getDoctorId() == doctor_id) {
                System.out.println("Doctor ID already exists!");
                return;
            }
        }

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Specialization: ");
        String specialization = scanner.nextLine();

        System.out.print("Enter Contact: ");
        String contact = scanner.nextLine();

        doctors.add(new Doctor_info(doctor_id, name, specialization, contact));
        System.out.println("Doctor added successfully!");

        saveDoctorsToFile(); // Save immediately after adding
    }

    public static void viewDoctors() {
        if (doctors.isEmpty()) {
            System.out.println("No doctors available.");
            return;
        }

        System.out.println("\n--- Doctor List ---");
        for (Doctor_info d : doctors) {
            d.displayDoctorInfo();
        }
    }
}