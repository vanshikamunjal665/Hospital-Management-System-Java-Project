/**
 * 
 */
/**
 * 
 */
module JavaProjectHospital {
}