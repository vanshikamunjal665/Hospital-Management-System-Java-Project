package wellness;

public class WellnessReport {
    
    private String patientName;
    private int score;
    private String recommendation;

    public WellnessReport(String patientName, int score, String recommendation) {
        this.patientName = patientName;
        this.score = score;
        this.recommendation = recommendation;
    }

    public void displayReport() {
        System.out.println("\n--- Wellness Report ---");
        System.out.println("Patient Name    : " + patientName);
        System.out.println("Score           : " + score + "/4");
        System.out.println("Recommendation  : " + recommendation);
    }

    public boolean needsCounseling() {
        return recommendation.toLowerCase().contains("counselor");
    }
}