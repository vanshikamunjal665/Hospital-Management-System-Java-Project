package wellness;

import java.util.Scanner;
import patient.Patient_info;

public class WellnessBot {
    private static Scanner scanner = new Scanner(System.in);

    public static void checkIn(String patientName) {
        System.out.println("\n-- Daily Mental Wellness Check for " + patientName + " ---");

        int score = 0;

        System.out.print("1. Are you feeling stressed or anxious? (yes/no): ");
        String q1 = scanner.nextLine();
        if (q1.equalsIgnoreCase("yes")) score++;

        System.out.print("2. Did you sleep well last night? (yes/no): ");
        String q2 = scanner.nextLine();
        if (q2.equalsIgnoreCase("no")) score++;

        System.out.print("3. Do you feel motivated today? (yes/no): ");
        String q3 = scanner.nextLine();
        if (q3.equalsIgnoreCase("no")) score++;

        System.out.print("4. Would you like to talk to someone about your feelings? (yes/no): ");
        String q4 = scanner.nextLine();
        if (q4.equalsIgnoreCase("yes")) score++;

        System.out.println("\n--- Mental Health Summary ---");

        String recommendation;

        if (score >= 3) {
            recommendation = "Assign a counselor or inform doctor.";
        } else if (score == 2) {
            recommendation = "Mild signs of distress. Monitor patient regularly.";
        } else {
            recommendation = "Patient is mentally stable.";
        }

        WellnessReport report = new WellnessReport(patientName, score, recommendation);
        report.displayReport();

        if (report.needsCounseling()) {
            System.out.println("Alert sent to doctor: Patient may need mental health support!");
        }
    }

    public static void startSession(Patient_info wellnessPatient) {
        if (wellnessPatient != null) {
            checkIn(wellnessPatient.getname()); // Assuming getName() exists in Patient_info
        } else {
            System.out.println("Invalid patient information.");
        }
    }
}