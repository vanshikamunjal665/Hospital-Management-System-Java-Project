package emergency;

public class EmergencyService{
	public static void triggerEmergency(int patientId, String location) {
		System.out.println("\n Emergency triggered!");
		System.out.println("Patient ID:"+ patientId);
		System.out.println("Location:"+ location);
		System.out.println("Alerting nearby ambulance...");
		System.out.println("Ambulance dispached to:"+location+"\n");
	}
}