import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class HospitalManagementGUI {
    static class Patient {
        String id, name, disease;

        Patient(String id, String name, String disease) {
            this.id = id;
            this.name = name;
            this.disease = disease;
        }
    }

    static class Doctor {
        String id, name, specialization;

        Doctor(String id, String name, String specialization) {
            this.id = id;
            this.name = name;
            this.specialization = specialization;
        }
    }

    static class Appointment {
        String patientId, doctorId, datetime;

        Appointment(String patientId, String doctorId, String datetime) {
            this.patientId = patientId;
            this.doctorId = doctorId;
            this.datetime = datetime;
        }
    }

    static ArrayList<Patient> patients = new ArrayList<>();
    static ArrayList<Doctor> doctors = new ArrayList<>();
    static ArrayList<Appointment> appointments = new ArrayList<>();

    private JTextField patientIdField, patientNameField, patientDiseaseField;
    private JTextField doctorIdField, doctorNameField, doctorSpecializationField;
    private JTextField appointmentPatientIdField, appointmentDoctorIdField, appointmentDateTimeField;
    private JTextArea displayArea;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HospitalManagementGUI().createAndShowGUI());
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame("Hospital Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 600);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(12, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Input"));

        // Patient Fields
        patientIdField = new JTextField();
        patientNameField = new JTextField();
        patientDiseaseField = new JTextField();

        inputPanel.add(new JLabel("Patient ID:")); inputPanel.add(patientIdField);
        inputPanel.add(new JLabel("Patient Name:")); inputPanel.add(patientNameField);
        inputPanel.add(new JLabel("Patient Disease:")); inputPanel.add(patientDiseaseField);

        // Doctor Fields
        doctorIdField = new JTextField();
        doctorNameField = new JTextField();
        doctorSpecializationField = new JTextField();

        inputPanel.add(new JLabel("Doctor ID:")); inputPanel.add(doctorIdField);
        inputPanel.add(new JLabel("Doctor Name:")); inputPanel.add(doctorNameField);
        inputPanel.add(new JLabel("Doctor Specialization:")); inputPanel.add(doctorSpecializationField);

        // Appointment Fields
        appointmentPatientIdField = new JTextField();
        appointmentDoctorIdField = new JTextField();
        appointmentDateTimeField = new JTextField();

        inputPanel.add(new JLabel("Appointment Patient ID:")); inputPanel.add(appointmentPatientIdField);
        inputPanel.add(new JLabel("Appointment Doctor ID:")); inputPanel.add(appointmentDoctorIdField);
        inputPanel.add(new JLabel("Appointment Date/Time:")); inputPanel.add(appointmentDateTimeField);

        frame.add(inputPanel, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 4, 5, 5));

        buttonPanel.add(createButton("Add Patient", e -> addPatient()));
        buttonPanel.add(createButton("Add Doctor", e -> addDoctor()));
        buttonPanel.add(createButton("View Patients", e -> viewPatients()));
        buttonPanel.add(createButton("View Doctors", e -> viewDoctors()));
        buttonPanel.add(createButton("Schedule Appointment", e -> scheduleAppointment()));
        buttonPanel.add(createButton("View Appointments", e -> viewAppointments()));

        frame.add(buttonPanel, BorderLayout.CENTER);

        // Display Area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Output"));

        frame.add(scrollPane, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    private JButton createButton(String title, ActionListener listener) {
        JButton button = new JButton(title);
        button.addActionListener(listener);
        return button;
    }

    private void addPatient() {
        String id = patientIdField.getText().trim();
        String name = patientNameField.getText().trim();
        String disease = patientDiseaseField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || disease.isEmpty()) {
            displayArea.append("Please fill all patient fields.\n");
            return;
        }

        patients.add(new Patient(id, name, disease));
        displayArea.append("Patient added: " + name + "\n");

        patientIdField.setText("");
        patientNameField.setText("");
        patientDiseaseField.setText("");
    }

    private void addDoctor() {
        String id = doctorIdField.getText().trim();
        String name = doctorNameField.getText().trim();
        String specialization = doctorSpecializationField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || specialization.isEmpty()) {
            displayArea.append("Please fill all doctor fields.\n");
            return;
        }

        doctors.add(new Doctor(id, name, specialization));
        displayArea.append("Doctor added: " + name + "\n");

        doctorIdField.setText("");
        doctorNameField.setText("");
        doctorSpecializationField.setText("");
    }

    private void viewPatients() {
        displayArea.append("\nList of Patients:\n");
        displayArea.append(String.format("%-10s %-20s %-20s\n", "ID", "Name", "Disease"));
        displayArea.append("--------------------------------------------------------\n");
        for (Patient p : patients) {
            displayArea.append(String.format("%-10s %-20s %-20s\n", p.id, p.name, p.disease));
        }
    }

    private void viewDoctors() {
        displayArea.append("\nList of Doctors:\n");
        displayArea.append(String.format("%-10s %-20s %-20s\n", "ID", "Name", "Specialization"));
        displayArea.append("--------------------------------------------------------\n");
        for (Doctor d : doctors) {
            displayArea.append(String.format("%-10s %-20s %-20s\n", d.id, d.name, d.specialization));
        }
    }

    private void scheduleAppointment() {
        String pid = appointmentPatientIdField.getText().trim();
        String did = appointmentDoctorIdField.getText().trim();
        String datetime = appointmentDateTimeField.getText().trim();

        boolean patientExists = patients.stream().anyMatch(p -> p.id.equals(pid));
        boolean doctorExists = doctors.stream().anyMatch(d -> d.id.equals(did));

        if (!patientExists || !doctorExists) {
            displayArea.append("Error: Invalid patient or doctor ID.\n");
            return;
        }

        appointments.add(new Appointment(pid, did, datetime));
        displayArea.append("Appointment Scheduled:\n");
        displayArea.append("Patient ID: " + pid + ", Doctor ID: " + did + ", Date/Time: " + datetime + "\n");

        appointmentPatientIdField.setText("");
        appointmentDoctorIdField.setText("");
        appointmentDateTimeField.setText("");
    }

    private void viewAppointments() {
        displayArea.append("\nScheduled Appointments:\n");
        displayArea.append(String.format("%-15s %-15s %-30s\n", "Patient ID", "Doctor ID", "Date/Time"));
        displayArea.append("--------------------------------------------------------------\n");

        if (appointments.isEmpty()) {
            displayArea.append("No appointments scheduled.\n");
        } else {
            for (Appointment a : appointments) {
                displayArea.append(String.format("%-15s %-15s %-30s\n", a.patientId, a.doctorId, a.datetime));
            }
        }
    }
}