package patient;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;

import doctor.Doctor_management;
import appointment.AppointmentScheduler;
import billing.Billing;
import emergency.EmergencyService;
import wellness.WellnessBot;

public class Patient_management_system {
    private static ArrayList<Patient_info> patients = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // Method to add a patient
    public static void addPatient() {
        System.out.print("Enter Patient ID: ");
        int patient_id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Name: ");
        String patient_name = scanner.nextLine();

        System.out.print("Enter Age: ");
        int patient_age = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Address: ");
        String patient_address = scanner.nextLine();

        System.out.print("Enter Contact: ");
        String patient_contact = scanner.nextLine();

        System.out.print("Enter Disease: ");
        String disease = scanner.nextLine();

        patients.add(new Patient_info(patient_name, patient_age, patient_id, patient_address, patient_contact, disease));
        System.out.println("Patient added successfully!\n");
    }

    // Method to view all patients
    public static void viewPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients found.");
            return;
        }
        System.out.println("\n--- Patient List ---");
        for (Patient_info p : patients) {
            p.display_patient_info();
        }
    }

    // Method to search a patient by ID
    public static void searchPatient() {
        System.out.print("Enter Patient ID to search: ");
        int id = scanner.nextInt();

        for (Patient_info p : patients) {
            if (p.getid() == id) {
                System.out.println("Patient Found:");
                p.display_patient_info();
                return;
            }
        }
        System.out.println("Patient not found.\n");
    }

    // Method to delete a patient by ID
    public static void deletePatient() {
        System.out.print("Enter Patient ID to delete: ");
        int id = scanner.nextInt();

        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getid() == id) {
                patients.remove(i);
                System.out.println("Patient deleted successfully.\n");
                return;
            }
        }
        System.out.println("Patient not found.\n");
    }

    // Load patients from file
    public static void loadPatientsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("patients.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                int patient_id = Integer.parseInt(data[0]);
                String patient_name = data[1];
                int patient_age = Integer.parseInt(data[2]);
                String patient_address = data[3];
                String patient_contact = data[4];
                String disease = data[5];

                patients.add(new Patient_info(patient_name, patient_age, patient_id, patient_address, patient_contact, disease));
            }
        } catch (IOException e) {
            System.out.println("Error loading patients from file.");
        }
    }

    // Save patients to file
    public static void savePatientsToFile() {
        try (FileWriter writer = new FileWriter("patients.txt")) {
            for (Patient_info p : patients) {
                writer.write(p.getid() + "," + p.getname() + "," + p.getage() + "," + p.getaddress() + "," + p.getcontact() + "," + p.getdisease() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error saving patients to file.");
        }
    }

    public static void main(String[] args) {
        // Load existing data
        loadPatientsFromFile();
        Doctor_management.loadDoctorsFromFile(); // 🔄 Load doctor data on startup

        // Main menu
        while (true) {
            System.out.println("\n--- Hospital Management System ---");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patients");
            System.out.println("3. Search Patient");
            System.out.println("4. Delete Patient"); // Added delete option
            System.out.println("5. Manage Doctors");
            System.out.println("6. Schedule Appointment");
            System.out.println("7. Generate Bill");
            System.out.println("8. Trigger Emergency");
            System.out.println("9. Mental Wellness Check-in");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addPatient();
                    break;
                case 2:
                    viewPatients();
                    break;
                case 3:
                    searchPatient();
                    break;
                case 4:
                    deletePatient(); // Call delete patient method
                    break;
                case 5:
                    Doctor_management.addDoctor();
                    Doctor_management.saveDoctorsToFile(); // 💾 Save doctor after adding
                    Doctor_management.viewDoctors();
                    break;
                case 6:
                    AppointmentScheduler.scheduleAppointment(patients);
                    break;
                case 7:
                    System.out.print("Enter Patient ID for billing: ");
                    int billingId = scanner.nextInt();
                    scanner.nextLine();
                    Patient_info patient = null;
                    for (Patient_info p : patients) {
                        if (p.getid() == billingId) {
                            patient = p;
                            break;
                        }
                    }
                    if (patient != null) {
                        Billing.generateBill(patient);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 8:
                    System.out.print("Enter Patient ID for emergency: ");
                    int emergencyId = scanner.nextInt();
                    scanner.nextLine();
                    Patient_info emergencyPatient = null;
                    for (Patient_info p : patients) {
                        if (p.getid() == emergencyId) {
                            emergencyPatient = p;
                            break;
                        }
                    }
                    if (emergencyPatient != null) {
                        System.out.print("Enter emergency location: ");
                        String location = scanner.nextLine();
                        EmergencyService.triggerEmergency(emergencyId, location);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 9:
                    System.out.print("Enter Patient ID for wellness check: ");
                    int wellnessId = scanner.nextInt();
                    scanner.nextLine();
                    Patient_info wellnessPatient = null;
                    for (Patient_info p : patients) {
                        if (p.getid() == wellnessId) {
                            wellnessPatient = p;
                            break;
                        }
                    }
                    if (wellnessPatient != null) {
                        WellnessBot.startSession(wellnessPatient);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 10:
                    savePatientsToFile(); // Save patients before exit
                    Doctor_management.saveDoctorsToFile(); // Save doctors before exit
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}