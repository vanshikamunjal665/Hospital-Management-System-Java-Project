package patient;

public class Patient_info {
    private String patient_name;
    private int patient_age;
    private int patient_id;
    private String patient_address;
    private String patient_contact; 
    private String disease;

    public Patient_info(String patient_name, int patient_age, int patient_id, String patient_address, String patient_contact, String disease) {
        this.patient_name = patient_name;
        this.patient_age = patient_age;
        this.patient_id = patient_id;
        this.patient_address = patient_address;
        this.patient_contact = patient_contact;
        this.disease = disease;
    }

    // Getters for patient_info
    public int getid() {
        return patient_id;
    }
    
    public String getname() {
        return patient_name;
    }

    public int getage() {
        return patient_age;
    }

    public String getdisease() {
        return disease;
    }

    public String getaddress() {
        return patient_address;
    }

    public String getcontact() {
        return patient_contact;
    }

    public void display_patient_info() {
        System.out.println("\n--- Patient Details ---");
        System.out.println("ID       : " + patient_id);
        System.out.println("Name     : " + patient_name);
        System.out.println("Age      : " + patient_age);
        System.out.println("Address  : " + patient_address);
        System.out.println("Contact  : " + patient_contact);
        System.out.println("Disease  : " + disease);
        System.out.println("----------------------------");
    }
}